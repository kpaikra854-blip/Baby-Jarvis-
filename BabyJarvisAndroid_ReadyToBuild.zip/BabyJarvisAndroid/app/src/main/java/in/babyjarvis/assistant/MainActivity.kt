package in.babyjarvis.assistant

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private val requestCode = 41
    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(36, 64, 36, 36)
            setBackgroundColor(0xFF071629.toInt())
        }
        val title = TextView(this).apply {
            text = "HEY JARVIS\nHindi Voice Assistant"
            textSize = 26f
            setTextColor(0xFF8BD5FF.toInt())
        }
        status = TextView(this).apply {
            text = "सेवा शुरू करने के लिए अनुमति दें।"
            textSize = 16f
            setTextColor(0xFFFFFFFF.toInt())
            setPadding(0, 28, 0, 28)
        }
        val start = Button(this).apply {
            text = "START JARVIS"
            setOnClickListener { requestAndStart() }
        }
        val stop = Button(this).apply {
            text = "STOP JARVIS"
            setOnClickListener {
                stopService(Intent(this@MainActivity, JarvisService::class.java))
                status.text = "Jarvis बंद है।"
            }
        }
        layout.addView(title)
        layout.addView(status)
        layout.addView(start)
        layout.addView(stop)
        setContentView(layout)
    }

    private fun requestAndStart() {
        val permissions = mutableListOf(Manifest.permission.RECORD_AUDIO)
        if (Build.VERSION.SDK_INT >= 33) permissions.add(Manifest.permission.POST_NOTIFICATIONS)
        val missing = permissions.filter {
            checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED
        }
        if (missing.isNotEmpty()) {
            requestPermissions(missing.toTypedArray(), requestCode)
        } else {
            startJarvis()
        }
    }

    private fun startJarvis() {
        try {
            val intent = Intent(this, JarvisService::class.java)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(intent)
            else startService(intent)
            status.text = "Jarvis चालू है। Notification में ACTIVE दिखाई देगा।"
        } catch (e: Exception) {
            status.text = "शुरू नहीं हो पाया: ${e.localizedMessage}"
            Toast.makeText(this, status.text, Toast.LENGTH_LONG).show()
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int, permissions: Array<out String>, grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == this.requestCode &&
            grantResults.isNotEmpty() &&
            grantResults[0] == PackageManager.PERMISSION_GRANTED
        ) {
            startJarvis()
        } else {
            status.text = "माइक्रोफोन अनुमति जरूरी है।"
        }
    }
}
