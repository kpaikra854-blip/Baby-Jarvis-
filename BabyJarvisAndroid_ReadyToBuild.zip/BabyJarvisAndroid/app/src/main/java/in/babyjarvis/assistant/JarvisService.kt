package in.babyjarvis.assistant

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class JarvisService : Service(), TextToSpeech.OnInitListener {
    companion object {
        private const val CHANNEL_ID = "baby_jarvis_mic"
        private const val NOTIFICATION_ID = 7001
        private const val ACTION_STOP = "in.babyjarvis.assistant.STOP"
    }

    private val handler = Handler(Looper.getMainLooper())
    private var recognizer: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var listeningForCommand = false
    private var running = false

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
        tts = TextToSpeech(this, this)
        startAsForeground()
        running = true
        startRecognition()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }
        // User must start the microphone service from the visible app screen.
        return START_NOT_STICKY
    }

    private fun startAsForeground() {
        val notification = buildNotification()
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(
                NOTIFICATION_ID,
                notification,
                ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
            )
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel(
                CHANNEL_ID, "Baby Jarvis microphone service",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "दिखाता है कि Baby Jarvis माइक्रोफोन से Wake Word सुन रहा है"
            }
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    private fun buildNotification(): Notification {
        val openApp = PendingIntent.getActivity(
            this, 1, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or immutableFlag()
        )
        val stopIntent = Intent(this, JarvisService::class.java).setAction(ACTION_STOP)
        val stopPending = PendingIntent.getService(
            this, 2, stopIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or immutableFlag()
        )
        val builder = if (Build.VERSION.SDK_INT >= 26) {
            Notification.Builder(this, CHANNEL_ID)
        } else {
            @Suppress("DEPRECATION")
            Notification.Builder(this)
        }
        return builder
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentTitle("BABY JARVIS ACTIVE")
            .setContentText("“Hey Jarvis” सुन रहा है · रोकने के लिए STOP")
            .setContentIntent(openApp)
            .setOngoing(true)
            .addAction(android.R.drawable.ic_media_pause, "STOP", stopPending)
            .build()
    }

    private fun immutableFlag(): Int =
        if (Build.VERSION.SDK_INT >= 23) PendingIntent.FLAG_IMMUTABLE else 0

    private fun startRecognition() {
        if (!running) return
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            speak("इस फोन में Speech Recognition सेवा उपलब्ध नहीं है। ऐप की सेटिंग जाँचें।")
            stopSelf()
            return
        }
        try {
            if (recognizer == null) {
                recognizer = SpeechRecognizer.createSpeechRecognizer(this).apply {
                    setRecognitionListener(object : RecognitionListener {
                        override fun onReadyForSpeech(params: android.os.Bundle?) {}
                        override fun onBeginningOfSpeech() {}
                        override fun onRmsChanged(rmsdB: Float) {}
                        override fun onBufferReceived(buffer: ByteArray?) {}
                        override fun onEndOfSpeech() {}
                        override fun onError(error: Int) {
                            scheduleRecognition(900)
                        }
                        override fun onResults(results: android.os.Bundle?) {
                            val text = results
                                ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                                ?.firstOrNull().orEmpty()
                            handleRecognizedText(text)
                        }
                        override fun onPartialResults(partialResults: android.os.Bundle?) {}
                        override fun onEvent(eventType: Int, params: android.os.Bundle?) {}
                    })
                }
            }
            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN")
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "hi-IN")
                putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
                putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
            }
            recognizer?.startListening(intent)
        } catch (_: Exception) {
            scheduleRecognition(1500)
        }
    }

    private fun scheduleRecognition(delay: Long) {
        if (running) handler.postDelayed({ startRecognition() }, delay)
    }

    private fun handleRecognizedText(raw: String) {
        val text = raw.lowercase(Locale.ROOT).trim()
        if (!listeningForCommand) {
            if (text.contains("hey jarvis") || text.contains("हे जार्विस") ||
                text.contains("हाय जार्विस") || text.contains("जार्विस")) {
                listeningForCommand = true
                speak("जी, बताइए।")
                scheduleRecognition(1800)
            } else {
                scheduleRecognition(400)
            }
            return
        }

        listeningForCommand = false
        when {
            text.contains("instagram") || text.contains("इंस्टाग्राम") ->
                openApp("com.instagram.android", "इंस्टाग्राम खोल रहा हूँ।")
            text.contains("youtube") || text.contains("यूट्यूब") ->
                openApp("com.google.android.youtube", "यूट्यूब खोल रहा हूँ।")
            text.contains("chrome") || text.contains("क्रोम") ->
                openApp("com.android.chrome", "क्रोम खोल रहा हूँ।")
            text.contains("समय") || text.contains("टाइम") -> {
                val time = SimpleDateFormat("hh:mm a", Locale("hi", "IN")).format(Date())
                speak("अभी समय है $time")
                scheduleRecognition(1800)
            }
            text.contains("तारीख") || text.contains("डेट") -> {
                val date = SimpleDateFormat("EEEE, d MMMM yyyy", Locale("hi", "IN")).format(Date())
                speak("आज $date है")
                scheduleRecognition(1800)
            }
            text.contains("सर्च") || text.contains("खोजो") || text.contains("search") -> {
                val query = text
                    .replace("गूगल पर", "").replace("google पर", "")
                    .replace("सर्च करो", "").replace("सर्च", "")
                    .replace("खोजो", "").trim()
                val q = if (query.isBlank()) "भारत की ताजा खबरें" else query
                speak("गूगल पर खोज रहा हूँ।")
                val browser = Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=" + Uri.encode(q)))
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                startActivity(browser)
                scheduleRecognition(2200)
            }
            text.contains("बंद") || text.contains("रुक जाओ") -> {
                speak("ठीक है, Jarvis बंद कर रहा हूँ।")
                handler.postDelayed({ stopSelf() }, 1200)
            }
            else -> {
                speak("माफ कीजिए, कमांड समझ नहीं आया।")
                scheduleRecognition(1800)
            }
        }
    }

    private fun openApp(packageName: String, message: String) {
        speak(message)
        val launch = packageManager.getLaunchIntentForPackage(packageName)
        if (launch != null) {
            launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            handler.postDelayed({ try { startActivity(launch) } catch (_: Exception) {} }, 700)
        } else {
            speak("यह ऐप आपके फोन में इंस्टॉल नहीं है।")
        }
        scheduleRecognition(2200)
    }

    private fun speak(message: String) {
        if (ttsReady) {
            tts?.speak(message, TextToSpeech.QUEUE_FLUSH, null, "jarvis_${System.currentTimeMillis()}")
        }
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            val result = tts?.setLanguage(Locale("hi", "IN"))
            ttsReady = result != TextToSpeech.LANG_MISSING_DATA &&
                result != TextToSpeech.LANG_NOT_SUPPORTED
        }
    }

    override fun onDestroy() {
        running = false
        handler.removeCallbacksAndMessages(null)
        try { recognizer?.cancel(); recognizer?.destroy() } catch (_: Exception) {}
        recognizer = null
        tts?.stop()
        tts?.shutdown()
        tts = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
