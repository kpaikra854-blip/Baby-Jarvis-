# Baby Jarvis — Hindi Voice Assistant (Android Starter)

यह Android Studio project है। इसमें APK पहले से शामिल नहीं है; GitHub Actions या Android Studio से APK build किया जा सकता है।

## इस version में क्या है
- START JARVIS दबाने पर microphone foreground service शुरू होती है।
- Notification में `BABY JARVIS ACTIVE` और STOP बटन दिखाई देता है।
- Hindi speech recognition से “Hey Jarvis”, “हे जार्विस” या “जार्विस” पहचानने की कोशिश करता है।
- अगली आवाज़ में कुछ basic commands: Instagram खोलो, YouTube खोलो, Chrome खोलो, समय बताओ, तारीख बताओ, Google पर ... search करो।
- हिंदी Text-to-Speech जवाब देने की कोशिश करता है।

## जरूरी सीमाएँ
1. यह starter prototype है, पूर्ण commercial assistant नहीं। यह Android की SpeechRecognizer सेवा पर निर्भर है। पहचान की भाषा/गुणवत्ता फोन में उपलब्ध speech service और language pack पर निर्भर करेगी; इंटरनेट की जरूरत पड़ सकती है।
2. यह dedicated offline wake-word engine नहीं है। इसलिए हमेशा “Hey Jarvis” की पहचान हर फोन पर लगातार या भरोसेमंद रूप से नहीं होगी।
3. Android 14+ में microphone foreground service को ऐप की खुली हुई screen से permission मिलने के बाद ही शुरू किया जाता है। Notification जानबूझकर दिखाई जाती है।
4. फोन की battery management सेवा को रोक सकती है। फोन restart होने पर ऐप खोलकर START फिर दबाना होगा।
5. यह source project है; कोई APK इस ZIP में मौजूद नहीं है।

## फोन से APK بنانے का तरीका (GitHub Actions)
1. GitHub पर account खोलें और **New repository** बनाएं। नाम रखें `BabyJarvis` और Public या Private चुनें।
2. इस ZIP को फोन में extract करें। अंदर की सभी files और `.github` folder सहित project files repository के main page पर **Add file → Upload files** से upload करें। ध्यान दें: `.github/workflows/build-apk.yml` भी upload होना चाहिए।
3. Upload/commit पूरा होने पर repository में **Actions** tab खोलें।
4. `Build Baby Jarvis APK` workflow चुनें। अगर push पर build अपने-आप शुरू नहीं हुआ, तो **Run workflow → Run workflow** दबाएं।
5. Build पूरा होने पर उसी run के नीचे **Artifacts** में `Baby-Jarvis-debug-apk` डाउनलोड करें। ZIP खोलकर `app-debug.apk` निकालें।
6. APK पर tap करके install करें। Android पूछे तो केवल इसी अपने बनाए APK के लिए “Install unknown apps” अनुमति दें।
7. ऐप खोलें, Microphone और Notifications अनुमति दें, फिर START JARVIS दबाएं।

## Basic voice commands
- “Hey Jarvis” → “जी, बताइए।”
- “Instagram खोलो”
- “YouTube खोलो”
- “Chrome खोलो”
- “समय बताओ”
- “तारीख बताओ”
- “Google पर मौसम search करो”

## सुरक्षा
- माइक्रोफोन केवल user द्वारा ऐप में START दबाने के बाद चलता है।
- लगातार सुनने की स्थिति Notification में दिखाई देती है; STOP से बंद करें।
- यह ऐप कोई रिकॉर्डिंग फाइल सेव नहीं करता। SpeechRecognizer सेवा ऑडियो को अपने तरीके से process कर सकती है।
